import InputVideo from '../../ui/InputFile/InputVideo';
import styles from './upload-video.module.scss';
import axios from 'axios';
import { useMemo, useState } from 'react';
import ProgressBar from '../../ui/ProgressBar/ProgressBar';

const UploadVideoPage = () => {
    const [{ progress, err, success }, setStatus] = useState({})
    const onSubmit = async e => {
        e.preventDefault();
        const form = e.target;
        if ((form.video.files[0].size) / 1048576 >= 100) return setStatus({ err: 'Video size must be less than 100mb!' })

        const formData = new FormData(form);
        const config = {
            onUploadProgress: progress => setStatus({ progress: (progress.loaded / progress.total).toFixed() * 100 }),
            headers: { 'content-type': 'multipart/form-data' },
        }

        axios.post('/api/upload-video-v2', formData, config)
            .then(res => setStatus({ success: true }))
            .catch(err => setStatus({ err: err.response.message }))
    }
    return (
        <div className={styles.root}>
            <form className={styles.form} onSubmit={onSubmit}>
                {useMemo(() => (
                    <>
                        <h2 className={styles.title}>Upload a Vidoe</h2>
                        <div className={styles.main}>
                            <input className='input-field' required={true} placeholder='Title' name='title' />
                            <textarea className='input-field' required={true} placeholder='Description' name='description' rows={5}></textarea>
                            <InputVideo name='video' className={styles.videoWrapper} />
                        </div>
                    </>
                ), [])}
                {success && <p className={styles.success}>Video has been successfully uploaded</p>}
                {err && <p className={styles.danger}>{err}</p>}
                {progress && progress < 100 && <ProgressBar progress={progress} />}
                {(!progress || progress === 100) && (
                    <button className={`btn btn-primary ${styles.btn}`} disabled={progress === 100} loader={progress === 100 ? "loader" : ""}>Submit</button>
                )}
            </form>

        </div>
    )
}

export default UploadVideoPage;