import { model, Schema, models } from 'mongoose';

const Video = new Schema({
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    url: {
        type: String,
        required: true,
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'users',
    }
})

export default models.videos || model('videos', Video);