import { model, Schema } from 'mongoose';

const Payment = new Schema({
    details: Schema.Types.Mixed,
    customerId: String,
    paymentId: String
})

export default model('payments', Payment);